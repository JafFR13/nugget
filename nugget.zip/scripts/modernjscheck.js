'use strict';(function(){let pass=true;if((null??2)!==2)pass=false;if(pass)window["C3_ModernJSSupport_OK"]=true})();
